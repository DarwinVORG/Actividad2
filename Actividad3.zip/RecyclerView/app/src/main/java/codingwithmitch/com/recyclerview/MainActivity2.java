package codingwithmitch.com.recyclerview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    EditText txUser, txPass;
    Button btnLogin, btnClear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txUser = (EditText)findViewById(R.id.editTextTextPersonName);
        txPass = (EditText)findViewById(R.id.editTextTextPassword);


        btnLogin = (Button)findViewById(R.id.button);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String A_USER = txUser.getText().toString();
                String A_PASS = txPass.getText().toString();
                if (A_USER.equals("Willis") && A_PASS.equals("12345678")){

                    Intent intent=new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Usuario o Contraseña Invalidos", Toast.LENGTH_SHORT).show();
                }



            }
        });

        btnClear = (Button)findViewById(R.id.button2);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                txUser.getText().clear();
                txPass.getText().clear();

            }
        });
    }


}